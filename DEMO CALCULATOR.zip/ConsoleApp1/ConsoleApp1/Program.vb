Imports System

Module Program
    Sub Main()
        Dim Name As String
        Dim Surname As String
        Dim Age As Integer
        Console.WriteLine("Enter Name")
        Name = Console.ReadLine
        Console.WriteLine("Enter Surname")
        Surname = Console.ReadLine
        Console.WriteLine("Enter Age")
        Age = Console.ReadLine
        If Age > "25" Then
            Console.WriteLine("Congratulations, You qualify for exemption")
        ElseIf Age < "25" Then
            Console.WriteLine("Sorry, you dont qualify for exemption")
        End If
    End Sub
End Module
