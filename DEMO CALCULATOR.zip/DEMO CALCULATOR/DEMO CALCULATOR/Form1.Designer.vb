﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmDemoCalculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblCalculator = New System.Windows.Forms.Label()
        Me.lblLine_1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.tbxLine_1 = New System.Windows.Forms.TextBox()
        Me.tbxLine_2 = New System.Windows.Forms.TextBox()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnMc = New System.Windows.Forms.Button()
        Me.btnMr = New System.Windows.Forms.Button()
        Me.btnMplus = New System.Windows.Forms.Button()
        Me.btnClearAll = New System.Windows.Forms.Button()
        Me.btnDivision = New System.Windows.Forms.Button()
        Me.btnMultiply = New System.Windows.Forms.Button()
        Me.btnMinus = New System.Windows.Forms.Button()
        Me.btnPlus = New System.Windows.Forms.Button()
        Me.btnSeven = New System.Windows.Forms.Button()
        Me.btnEight = New System.Windows.Forms.Button()
        Me.btnNine = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnFour = New System.Windows.Forms.Button()
        Me.btnFive = New System.Windows.Forms.Button()
        Me.btnSix = New System.Windows.Forms.Button()
        Me.btnPoint = New System.Windows.Forms.Button()
        Me.btnZero = New System.Windows.Forms.Button()
        Me.btnOne = New System.Windows.Forms.Button()
        Me.btnTwo = New System.Windows.Forms.Button()
        Me.btnThree = New System.Windows.Forms.Button()
        Me.btnEqual = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblCalculator
        '
        Me.lblCalculator.AutoSize = True
        Me.lblCalculator.Font = New System.Drawing.Font("Segoe Print", 20.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle))
        Me.lblCalculator.Location = New System.Drawing.Point(91, 9)
        Me.lblCalculator.Name = "lblCalculator"
        Me.lblCalculator.Size = New System.Drawing.Size(313, 47)
        Me.lblCalculator.TabIndex = 0
        Me.lblCalculator.Text = "DEMO CALCULATOR"
        '
        'lblLine_1
        '
        Me.lblLine_1.AutoSize = True
        Me.lblLine_1.Font = New System.Drawing.Font("Comic Sans MS", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLine_1.Location = New System.Drawing.Point(12, 74)
        Me.lblLine_1.Name = "lblLine_1"
        Me.lblLine_1.Size = New System.Drawing.Size(76, 27)
        Me.lblLine_1.TabIndex = 1
        Me.lblLine_1.Text = "Line 1:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Comic Sans MS", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(12, 112)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 27)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Line 2:"
        '
        'tbxLine_1
        '
        Me.tbxLine_1.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.tbxLine_1.Font = New System.Drawing.Font("Verdana", 14.0!)
        Me.tbxLine_1.Location = New System.Drawing.Point(94, 74)
        Me.tbxLine_1.Name = "tbxLine_1"
        Me.tbxLine_1.ReadOnly = True
        Me.tbxLine_1.Size = New System.Drawing.Size(393, 30)
        Me.tbxLine_1.TabIndex = 3
        Me.tbxLine_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'tbxLine_2
        '
        Me.tbxLine_2.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.tbxLine_2.Font = New System.Drawing.Font("Verdana", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tbxLine_2.Location = New System.Drawing.Point(94, 112)
        Me.tbxLine_2.Name = "tbxLine_2"
        Me.tbxLine_2.ReadOnly = True
        Me.tbxLine_2.Size = New System.Drawing.Size(393, 30)
        Me.tbxLine_2.TabIndex = 4
        Me.tbxLine_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnCancel
        '
        Me.btnCancel.Font = New System.Drawing.Font("Comic Sans MS", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancel.Location = New System.Drawing.Point(17, 152)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(101, 47)
        Me.btnCancel.TabIndex = 5
        Me.btnCancel.Text = "CANCEL"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnMc
        '
        Me.btnMc.Font = New System.Drawing.Font("Comic Sans MS", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMc.Location = New System.Drawing.Point(139, 152)
        Me.btnMc.Name = "btnMc"
        Me.btnMc.Size = New System.Drawing.Size(101, 47)
        Me.btnMc.TabIndex = 6
        Me.btnMc.Text = "MC"
        Me.btnMc.UseVisualStyleBackColor = True
        '
        'btnMr
        '
        Me.btnMr.Font = New System.Drawing.Font("Comic Sans MS", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMr.Location = New System.Drawing.Point(266, 152)
        Me.btnMr.Name = "btnMr"
        Me.btnMr.Size = New System.Drawing.Size(101, 47)
        Me.btnMr.TabIndex = 7
        Me.btnMr.Text = "MR"
        Me.btnMr.UseVisualStyleBackColor = True
        '
        'btnMplus
        '
        Me.btnMplus.Font = New System.Drawing.Font("Comic Sans MS", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMplus.Location = New System.Drawing.Point(387, 152)
        Me.btnMplus.Name = "btnMplus"
        Me.btnMplus.Size = New System.Drawing.Size(101, 47)
        Me.btnMplus.TabIndex = 8
        Me.btnMplus.Text = "M+"
        Me.btnMplus.UseVisualStyleBackColor = True
        '
        'btnClearAll
        '
        Me.btnClearAll.Font = New System.Drawing.Font("Comic Sans MS", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClearAll.Location = New System.Drawing.Point(17, 205)
        Me.btnClearAll.Name = "btnClearAll"
        Me.btnClearAll.Size = New System.Drawing.Size(101, 90)
        Me.btnClearAll.TabIndex = 9
        Me.btnClearAll.Text = "CLEAR ALL"
        Me.btnClearAll.UseVisualStyleBackColor = True
        '
        'btnDivision
        '
        Me.btnDivision.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDivision.Location = New System.Drawing.Point(139, 205)
        Me.btnDivision.Name = "btnDivision"
        Me.btnDivision.Size = New System.Drawing.Size(59, 42)
        Me.btnDivision.TabIndex = 10
        Me.btnDivision.Text = "/"
        Me.btnDivision.UseVisualStyleBackColor = True
        '
        'btnMultiply
        '
        Me.btnMultiply.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMultiply.Location = New System.Drawing.Point(222, 205)
        Me.btnMultiply.Name = "btnMultiply"
        Me.btnMultiply.Size = New System.Drawing.Size(59, 42)
        Me.btnMultiply.TabIndex = 11
        Me.btnMultiply.Text = "X"
        Me.btnMultiply.UseVisualStyleBackColor = True
        '
        'btnMinus
        '
        Me.btnMinus.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMinus.Location = New System.Drawing.Point(308, 208)
        Me.btnMinus.Name = "btnMinus"
        Me.btnMinus.Size = New System.Drawing.Size(59, 42)
        Me.btnMinus.TabIndex = 12
        Me.btnMinus.Text = "-"
        Me.btnMinus.UseVisualStyleBackColor = True
        '
        'btnPlus
        '
        Me.btnPlus.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPlus.Location = New System.Drawing.Point(387, 208)
        Me.btnPlus.Name = "btnPlus"
        Me.btnPlus.Size = New System.Drawing.Size(101, 90)
        Me.btnPlus.TabIndex = 13
        Me.btnPlus.Text = "+"
        Me.btnPlus.UseVisualStyleBackColor = True
        '
        'btnSeven
        '
        Me.btnSeven.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSeven.Location = New System.Drawing.Point(139, 256)
        Me.btnSeven.Name = "btnSeven"
        Me.btnSeven.Size = New System.Drawing.Size(59, 42)
        Me.btnSeven.TabIndex = 14
        Me.btnSeven.Text = "7"
        Me.btnSeven.UseVisualStyleBackColor = True
        '
        'btnEight
        '
        Me.btnEight.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEight.Location = New System.Drawing.Point(222, 256)
        Me.btnEight.Name = "btnEight"
        Me.btnEight.Size = New System.Drawing.Size(59, 42)
        Me.btnEight.TabIndex = 15
        Me.btnEight.Text = "8"
        Me.btnEight.UseVisualStyleBackColor = True
        '
        'btnNine
        '
        Me.btnNine.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNine.Location = New System.Drawing.Point(308, 256)
        Me.btnNine.Name = "btnNine"
        Me.btnNine.Size = New System.Drawing.Size(59, 42)
        Me.btnNine.TabIndex = 16
        Me.btnNine.Text = "9"
        Me.btnNine.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Comic Sans MS", 14.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(12, 322)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(101, 42)
        Me.btnClose.TabIndex = 17
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnFour
        '
        Me.btnFour.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFour.Location = New System.Drawing.Point(139, 322)
        Me.btnFour.Name = "btnFour"
        Me.btnFour.Size = New System.Drawing.Size(59, 42)
        Me.btnFour.TabIndex = 18
        Me.btnFour.Text = "4"
        Me.btnFour.UseVisualStyleBackColor = True
        '
        'btnFive
        '
        Me.btnFive.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFive.Location = New System.Drawing.Point(222, 322)
        Me.btnFive.Name = "btnFive"
        Me.btnFive.Size = New System.Drawing.Size(59, 42)
        Me.btnFive.TabIndex = 19
        Me.btnFive.Text = "5"
        Me.btnFive.UseVisualStyleBackColor = True
        '
        'btnSix
        '
        Me.btnSix.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSix.Location = New System.Drawing.Point(308, 322)
        Me.btnSix.Name = "btnSix"
        Me.btnSix.Size = New System.Drawing.Size(59, 42)
        Me.btnSix.TabIndex = 20
        Me.btnSix.Text = "6"
        Me.btnSix.UseVisualStyleBackColor = True
        '
        'btnPoint
        '
        Me.btnPoint.Enabled = False
        Me.btnPoint.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPoint.Location = New System.Drawing.Point(387, 322)
        Me.btnPoint.Name = "btnPoint"
        Me.btnPoint.Size = New System.Drawing.Size(101, 42)
        Me.btnPoint.TabIndex = 21
        Me.btnPoint.Text = ","
        Me.btnPoint.UseVisualStyleBackColor = True
        '
        'btnZero
        '
        Me.btnZero.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnZero.Location = New System.Drawing.Point(12, 370)
        Me.btnZero.Name = "btnZero"
        Me.btnZero.Size = New System.Drawing.Size(101, 42)
        Me.btnZero.TabIndex = 22
        Me.btnZero.Text = "0"
        Me.btnZero.UseVisualStyleBackColor = True
        '
        'btnOne
        '
        Me.btnOne.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOne.Location = New System.Drawing.Point(139, 370)
        Me.btnOne.Name = "btnOne"
        Me.btnOne.Size = New System.Drawing.Size(59, 42)
        Me.btnOne.TabIndex = 23
        Me.btnOne.Text = "1"
        Me.btnOne.UseVisualStyleBackColor = True
        '
        'btnTwo
        '
        Me.btnTwo.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTwo.Location = New System.Drawing.Point(222, 370)
        Me.btnTwo.Name = "btnTwo"
        Me.btnTwo.Size = New System.Drawing.Size(59, 42)
        Me.btnTwo.TabIndex = 24
        Me.btnTwo.Text = "2"
        Me.btnTwo.UseVisualStyleBackColor = True
        '
        'btnThree
        '
        Me.btnThree.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnThree.Location = New System.Drawing.Point(308, 370)
        Me.btnThree.Name = "btnThree"
        Me.btnThree.Size = New System.Drawing.Size(59, 42)
        Me.btnThree.TabIndex = 25
        Me.btnThree.Text = "3"
        Me.btnThree.UseVisualStyleBackColor = True
        '
        'btnEqual
        '
        Me.btnEqual.Font = New System.Drawing.Font("Consolas", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEqual.Location = New System.Drawing.Point(387, 370)
        Me.btnEqual.Name = "btnEqual"
        Me.btnEqual.Size = New System.Drawing.Size(101, 42)
        Me.btnEqual.TabIndex = 26
        Me.btnEqual.Text = "="
        Me.btnEqual.UseVisualStyleBackColor = True
        '
        'FrmDemoCalculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(500, 415)
        Me.Controls.Add(Me.btnEqual)
        Me.Controls.Add(Me.btnThree)
        Me.Controls.Add(Me.btnTwo)
        Me.Controls.Add(Me.btnOne)
        Me.Controls.Add(Me.btnZero)
        Me.Controls.Add(Me.btnPoint)
        Me.Controls.Add(Me.btnSix)
        Me.Controls.Add(Me.btnFive)
        Me.Controls.Add(Me.btnFour)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnNine)
        Me.Controls.Add(Me.btnEight)
        Me.Controls.Add(Me.btnSeven)
        Me.Controls.Add(Me.btnPlus)
        Me.Controls.Add(Me.btnMinus)
        Me.Controls.Add(Me.btnMultiply)
        Me.Controls.Add(Me.btnDivision)
        Me.Controls.Add(Me.btnClearAll)
        Me.Controls.Add(Me.btnMplus)
        Me.Controls.Add(Me.btnMr)
        Me.Controls.Add(Me.btnMc)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.tbxLine_2)
        Me.Controls.Add(Me.tbxLine_1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblLine_1)
        Me.Controls.Add(Me.lblCalculator)
        Me.Name = "FrmDemoCalculator"
        Me.Text = "Demo Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblCalculator As Label
    Friend WithEvents lblLine_1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents tbxLine_1 As TextBox
    Friend WithEvents tbxLine_2 As TextBox
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnMc As Button
    Friend WithEvents btnMr As Button
    Friend WithEvents btnMplus As Button
    Friend WithEvents btnClearAll As Button
    Friend WithEvents btnDivision As Button
    Friend WithEvents btnMultiply As Button
    Friend WithEvents btnMinus As Button
    Friend WithEvents btnPlus As Button
    Friend WithEvents btnSeven As Button
    Friend WithEvents btnEight As Button
    Friend WithEvents btnNine As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents btnFour As Button
    Friend WithEvents btnFive As Button
    Friend WithEvents btnSix As Button
    Friend WithEvents btnPoint As Button
    Friend WithEvents btnZero As Button
    Friend WithEvents btnOne As Button
    Friend WithEvents btnTwo As Button
    Friend WithEvents btnThree As Button
    Friend WithEvents btnEqual As Button
End Class
