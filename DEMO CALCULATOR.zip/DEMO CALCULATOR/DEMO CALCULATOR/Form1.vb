﻿
Public Class FrmDemoCalculator
    Dim number_1 As Integer
    Dim number_2 As Integer
    Dim sign As Char
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
    Private Sub btnZero_Click(sender As Object, e As EventArgs) Handles btnZero.Click
        If tbxLine_2.Text <> "0" Then
            tbxLine_2.Text += "0"
        Else
            tbxLine_2.Text = "0"
        End If
    End Sub

    Private Sub btnPoint_Click(sender As Object, e As EventArgs) Handles btnPoint.Click
        If tbxLine_2.Text <> "0" Then
            tbxLine_2.Text += ","
        Else
            tbxLine_2.Text = ","
        End If
    End Sub

    Private Sub btnOne_Click(sender As Object, e As EventArgs) Handles btnOne.Click
        If tbxLine_2.Text <> "0" Then
            tbxLine_2.Text += "1"
        Else
            tbxLine_2.Text = "1"
        End If
    End Sub

    Private Sub btnTwo_Click(sender As Object, e As EventArgs) Handles btnTwo.Click
        If tbxLine_2.Text <> "0" Then
            tbxLine_2.Text += "2"
        Else
            tbxLine_2.Text = "2"
        End If
    End Sub

    Private Sub btnThree_Click(sender As Object, e As EventArgs) Handles btnThree.Click
        If tbxLine_2.Text <> "0" Then
            tbxLine_2.Text += "3"
        Else
            tbxLine_2.Text = "3"
        End If
    End Sub

    Private Sub btnFour_Click(sender As Object, e As EventArgs) Handles btnFour.Click
        If tbxLine_2.Text <> "0" Then
            tbxLine_2.Text += "4"
        Else
            tbxLine_2.Text = "4"
        End If
    End Sub

    Private Sub btnFive_Click(sender As Object, e As EventArgs) Handles btnFive.Click
        If tbxLine_2.Text <> "0" Then
            tbxLine_2.Text += "5"
        Else
            tbxLine_2.Text = "5"
        End If
    End Sub

    Private Sub btnSix_Click(sender As Object, e As EventArgs) Handles btnSix.Click
        If tbxLine_2.Text <> "0" Then
            tbxLine_2.Text += "6"
        Else
            tbxLine_2.Text = "6"
        End If
    End Sub

    Private Sub btnSeven_Click(sender As Object, e As EventArgs) Handles btnSeven.Click
        If tbxLine_2.Text <> "0" Then
            tbxLine_2.Text += "7"
        Else
            tbxLine_2.Text = "7"
        End If
    End Sub

    Private Sub btnEight_Click(sender As Object, e As EventArgs) Handles btnEight.Click
        If tbxLine_2.Text <> "0" Then
            tbxLine_2.Text += "8"
        Else
            tbxLine_2.Text = "8"
        End If
    End Sub

    Private Sub btnNine_Click(sender As Object, e As EventArgs) Handles btnNine.Click
        If tbxLine_2.Text <> "0" Then
            tbxLine_2.Text += "9"
        Else
            tbxLine_2.Text = "9"
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        tbxLine_2.Clear()
    End Sub

    Private Sub btnClearAll_Click(sender As Object, e As EventArgs) Handles btnClearAll.Click
        tbxLine_2.Clear()
        tbxLine_1.Clear()
    End Sub

    Private Sub btnDivision_Click(sender As Object, e As EventArgs) Handles btnDivision.Click
        If tbxLine_2.Text = "" Then
        Else
            number_1 = tbxLine_2.Text
            tbxLine_2.Text = tbxLine_1.Text
            tbxLine_1.Text += "/"
            sign = "/"
            tbxLine_2.Clear()
        End If
        If btnPlus.Name = "btnDivision" Then
            tbxLine_1.Text = tbxLine_1.Text + "/"
        End If
    End Sub

    Private Sub btnMultiply_Click(sender As Object, e As EventArgs) Handles btnMultiply.Click
        If tbxLine_2.Text = "" Then
        Else
            number_1 = tbxLine_2.Text
            tbxLine_2.Text = tbxLine_1.Text
            tbxLine_1.Text += "X"
            sign = "X"
            tbxLine_2.Clear()
        End If
        If btnPlus.Name = "btnMultiply" Then
            tbxLine_1.Text = tbxLine_1.Text + "*"
        End If
    End Sub

    Private Sub btnMinus_Click(sender As Object, e As EventArgs) Handles btnMinus.Click
        If tbxLine_2.Text = "" Then
        Else
            number_1 = tbxLine_2.Text
            tbxLine_2.Text = tbxLine_1.Text
            tbxLine_1.Text += "-"
            sign = "-"
            tbxLine_2.Clear()
        End If
        If btnPlus.Name = "btnMinus" Then
            tbxLine_1.Text = tbxLine_1.Text + "-"
        End If
    End Sub

    Private Sub btnPlus_Click(sender As Object, e As EventArgs) Handles btnPlus.Click
        If tbxLine_2.Text = "" Then
        Else
            number_1 = tbxLine_2.Text
            tbxLine_2.Text = tbxLine_1.Text
            tbxLine_1.Text += "+"
            sign = "+"
            tbxLine_2.Clear()

        End If
        If btnPlus.Name = "btnPlus" Then
            tbxLine_1.Text = tbxLine_1.Text + "7+5"
        End If
    End Sub
End Class